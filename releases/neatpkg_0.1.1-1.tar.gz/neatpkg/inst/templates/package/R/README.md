# R folder

This is the most important folder of your package - it contains the R functions that form the basis of the package. It is a good idea to have a single R script per function, although it is also fine to have multiple related functions (usually sharing a help page) in the same file. See some of the example functions provided for inspiration.
