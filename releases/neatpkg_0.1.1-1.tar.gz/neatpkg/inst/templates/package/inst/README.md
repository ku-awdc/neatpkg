# inst folder

This folder contains the WORDLIST, which is a list of additional words for the spell checker to ignore.  You can also add any other files that you want to be installed within the package directory, although it is rare that you need to do this.
