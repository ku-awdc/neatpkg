# man folder

This folder contains the manual/help pages that are automatically created from the roxygen comments in your R code.  You should NOT modify anything in this folder manually.
