# vignettes folder

This folder contains vignettes, which help users to understand what your package does and how they can use it. It is recommended to have at least one vignette per package, although it is not essential. The easiest way to produce them is using R markdown - see the example provided.
