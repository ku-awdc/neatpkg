# data-raw folder

This folder contains scripts to clean data and turn it into pre-packaged datasets that you want to include in the package for your users. See the add_data.R script for details.

Note that the contents of this folder are not installed with the R package, but it will be on GitHub, so you should not add any sensitive data here.  

