.onAttach <- function(lib, pkg)
{
    packageStartupMessage("Welcome to neatpkg!\nTo get started see ?pkg_new - and remember fortunes::fortune(52) :")
	packageStartupMessage("
> Can one be a good data analyst without being a half-good programmer?
> The short answer to that is, 'No.'
> The long answer to that is, 'No.'
>   -- Frank Harrell
>      1999 S-PLUS User Conference, New Orleans (October 1999)
")
}
