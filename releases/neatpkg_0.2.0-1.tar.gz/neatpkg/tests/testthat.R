library("testthat")
library("neatpkg")

test_check("neatpkg")
