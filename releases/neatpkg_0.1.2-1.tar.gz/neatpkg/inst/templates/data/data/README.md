# data folder

This folder contains pre-packaged datasets that you want to include in the package for your users.  You should not add files here manually - see the data-raw folder for how to add data to a package.

