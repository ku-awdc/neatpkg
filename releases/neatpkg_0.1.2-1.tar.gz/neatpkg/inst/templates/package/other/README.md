# other folder

This folder can be used for any other files that you want to keep on the GitHub repository, but that are not needed for the R package itself. You do not need to use this folder, if this is not applicable to you.

