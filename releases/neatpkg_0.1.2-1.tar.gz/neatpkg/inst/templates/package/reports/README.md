# reports folder

This folder can be used for any Rmd scripts that generate particular outputs using your package. You do not need to use this folder, if this is not applicable to you.
