# neatpkg
create R packages quickly, using the ku-awdc recommended layout

## TODO

- escape .md in .Rbuildignore
- vignette/instructions
- offer to set up drat repo and author details in .profile if not present
- automatically enter author details in pkg_new if present
- pkg_data function
- pkg_R6 function
- pkg_rcpp function
