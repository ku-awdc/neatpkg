# neatpkg
create R packages quickly, using the ku-awdc recommended layout
