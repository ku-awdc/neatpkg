# local folder

This folder can be used for any files that you don't want to put onto GitHub for some reason.  However, you should not use this folder for anything important, as it is not versioned or backed up anywhere!
