#' @name template-package
#' @aliases template
#' @title What the Package Does (One Line, Title Case)
#'
#' @details
#' Some description of the package
#'
#' @examples
#' ## An example function:
#' df <- example_function()
#' df
#'
#' ## To cite this package in publications use:
#' citation("template")
#'
#' @seealso
#' \code{\link[neatpkg]{pkg_new}} for the function that created this package
#'
#' @references
#' Some article that you might want users to look at
#'
#' @keywords internal
"_PACKAGE"

## usethis namespace: start
## usethis namespace: end
NULL
