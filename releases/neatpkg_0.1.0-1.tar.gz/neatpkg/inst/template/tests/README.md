# tests folder

This folder is used for automated tests of your R code, which will be run by R CMD check. It is an extremely good idea to include tests in your package! The recommended setup is to use testthat, and place your tests under the testthat directory. See the test-example.R file provided for inspiration.
